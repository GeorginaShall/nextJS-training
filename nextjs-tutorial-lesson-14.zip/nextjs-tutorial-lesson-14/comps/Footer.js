const Footer = () => {
  return (
    <footer>
      Copyright 2021 Ninja List
    </footer>
  );
}
 
export default Footer;